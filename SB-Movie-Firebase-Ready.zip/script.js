import {initializeApp} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import {getAuth,signInWithEmailAndPassword,signOut} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
const firebaseConfig={apiKey:"AIzaSyAZvi2kXqw9bNhVdSG63hnl9hG_O4D2T5M",authDomain:"sb-movie-83e1e.firebaseapp.com",projectId:"sb-movie-83e1e",storageBucket:"sb-movie-83e1e.firebasestorage.app",messagingSenderId:"448621090040",appId:"1:448621090040:web:5387896cc090bb58c2d70d",measurementId:"G-R361ZHF88P"};
const auth=getAuth(initializeApp(firebaseConfig));
const $=s=>document.querySelector(s), status=$("#status");
$("#loginBtn").onclick=async()=>{try{await signInWithEmailAndPassword(auth,$("#email").value.trim(),$("#password").value);status.textContent="Login successful.";$("#loginBtn").hidden=true;$("#logoutBtn").hidden=false}catch(e){status.textContent="Login failed. Check your email and password."}};
$("#logoutBtn").onclick=async()=>{await signOut(auth);status.textContent="Logged out.";$("#loginBtn").hidden=false;$("#logoutBtn").hidden=true};
